// Game data structure
window.gameData = {
  money: 1000, // Starting money
  stock: [],   // Array of products in stock (custom products)
  demand: {},  // Demand for each product
  cooldowns: {
    sale: 0,
    hype: 0,
    bogo: 0,
    flashSale: 0,
    holidaySale: 0,
    vipVisit: 0
  }
};

// Function to create a new custom product (Starts with ZERO stock)
function createCustomProduct(name, description, price, imageURL) {
  if (!name) {
    alert("Product name cannot be empty.");
    return;
  }

  if (!description) {
    alert("Description cannot be empty.");
    return;
  }

  price = parseFloat(price);
  if (isNaN(price) || price <= 0) {
    alert("Price must be a valid positive number.");
    return;
  }

  const imagePattern = /^(http|https):\/\/[^\s$.?#].[^\s]*$/;
  if (!imageURL || !imagePattern.test(imageURL)) {
    alert("Please provide a valid image URL.");
    return;
  }

  const newProduct = {
    id: window.gameData.stock.length + 1,
    name: name,
    description: description,
    price: price,
    stock: 0, // Now starts with ZERO stock
    image: imageURL
  };

  window.gameData.stock.push(newProduct);
  window.gameData.demand[newProduct.id] = 1; // Default demand

  loadProducts();
  alert(`${name} has been added to the store! Now restock it to start selling.`);
}

// Load products in the store
function loadProducts() {
  const productContainer = document.getElementById("productContainer");
  productContainer.innerHTML = "";

  window.gameData.stock.forEach((product) => {
    const productElement = document.createElement("div");
    productElement.classList.add("product");

    productElement.innerHTML = `
      <img src="${product.image}" alt="${product.name}" class="productImage">
      <h3>${product.name}</h3>
      <p>${product.description}</p>
      <p>Price: $${product.price.toFixed(2)}</p>
      <p><strong>In Stock: ${product.stock}</strong></p>
      <p>Demand: ${window.gameData.demand[product.id]}</p>
      <button onclick="restockProduct(${product.id})">Restock</button>
    `;

    productContainer.appendChild(productElement);
  });

  updateMoneyDisplay();
}

// Buy more stock (Restocking) - FIXED COST CALCULATION
function restockProduct(productId) {
  const product = window.gameData.stock.find(p => p.id === productId);
  if (!product) return;

  const restockAmount = 10; // Restock in batches of 10
  const cost = product.price * restockAmount * 0.5; // 50% of the selling price per unit

  if (window.gameData.money >= cost) {
    product.stock += restockAmount;
    window.gameData.money -= cost;
    alert(`Restocked ${restockAmount} units of ${product.name} for $${cost.toFixed(2)}`);
  } else {
    alert("Not enough money to restock!");
  }

  loadProducts();
}

// Selling products automatically
function sellProducts() {
  window.gameData.stock.forEach((product) => {
    if (product.stock > 0) {
      const demand = window.gameData.demand[product.id] || 1;
      const sold = Math.min(product.stock, Math.floor(Math.random() * demand + 1));
      product.stock -= sold;
      window.gameData.money += sold * product.price;
      console.log(`Sold ${sold} units of ${product.name} for $${product.price * sold}`);
    }
  });

  loadProducts();
}

// Increase demand for a product
function increaseDemand(productId) {
  if (window.gameData.demand[productId]) {
    window.gameData.demand[productId] += 1;
  } else {
    window.gameData.demand[productId] = 1;
  }

  alert(`Demand for ${window.gameData.stock.find(p => p.id === productId).name} increased!`);
  loadProducts();
}

// Display money
function updateMoneyDisplay() {
  document.getElementById("moneyDisplay").textContent = `Money: $${window.gameData.money.toFixed(2)}`;
}

// Handle product creation form
function handleCreateProduct() {
  const name = document.getElementById("productName").value;
  const description = document.getElementById("productDescription").value;
  const price = document.getElementById("productPrice").value;
  const imageURL = document.getElementById("productImage").value;

  createCustomProduct(name, description, price, imageURL);
  document.getElementById("customProductForm").reset();
}

// Sell products every 10 seconds
setInterval(sellProducts, 10000);

// Load store on startup
window.onload = () => {
  loadProducts();
};
